﻿namespace UseCase.Core
{
    public interface IResponse
    {
    }
}
